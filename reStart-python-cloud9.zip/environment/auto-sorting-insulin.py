# autur take-on progammatically separating

mystring = ('malwmrllpllallalwgpdpaaafvnqhlcgshlvealylvcgergffytpktrreaedlqvgqvelgggpgagslqplalegslqkrgiveqcctsicslyqlenycn')

a = mystring

print("Your string is : ",a)
print("lsinsulin-seq-clean is : ",a[0:23])
print("binsulin-seq-clean is : ",a[24:53])
print("cinsulin-seq-clean is : ",a[54:88])
print("ainsulin-seq-clean is : ",a[89:109])